<?php
namespace Home\Controller;
use Common\Common\Controller\AdminBaseController;
class MallController extends AdminBaseController {
    
	public $locations = array();
	public $ptype_id;
	
	
	function __construct(){
		parent::__construct();
		$this->locations = array(
				array('is_checked'=>false, 'name'=>'商城管理', 'url'=>U('Mall/index'))
		);
		$this->assign('loc_name_1', "商城管理");
		$this->assign('locations', $this->locations);
	}
	
	public function index(){
		$this->assign("loc_name_2", "商城列表");
		$search_info['key'] = isset($_POST['key'])?$_POST['key']:'';
		$search_info['num'] = isset($_POST['num'])?intval($_POST['num']):isset($_GET['num'])?intval($_GET['num']):10;
		$this->assign('search_info', $search_info);
		$res = D('Mall')->search_info($search_info);
                $mall = M('mall')->where("is_del=0")->order("rank,id")->select();
                $this->assign('mall', $mall);
		$this->assign('show_page', $res['show_page']);
                
                $this->display("Mall/index");
    }
    
    public function add_info(){
    	$this->assign("loc_name_2", "添加");
    	$this->display();
    }
    
    public function create_info(){
        
        if( isset($_POST['mall']) && isset($_POST['mall_detail']) ){
    		$params = $_POST['mall'];
    		$params['detail'] = $_POST['mall_detail'];
    		$res = D('Mall')->create_info($params);
    		if( $res['status'] ){
    			$this->redirect("Mall/index");
                        
    		}else{
    			$_SESSION['notice'] = $res['msg'];
    		}
    	}else{
    		$_SESSION['notice'] = "参数错误";
    	}
    	$this->redirect('Home/Mall/add_info');
    	if( isset($_POST['mall']) ){
//    		$res = D('Mall')->create_info($_POST['mall']);
                $res = M('mall')->add($_POST['mall']);
                print_r($_POST['mall']);
                exit;
                if($res)
                {
                        $notice = "添加项目成功";
		}else{
                        $notice = "添加项目失败";
		}
    		$notice = $res['notice'];
                
    		if( $res['status'] ){
    			$this->set_notice(1, $notice);
    			$this->redirect("Mall/index");
    		}
    	}else{
    		$notice = "参数错误";
    	}
    	$this->set_notice(2, $notice);
    	$this->redirect('Mall/add_info');
    }
    
    public function edit(){
    	$this->assign("loc_name_2", "修改");
    	$mall = M('mall')->where("id=%d", array($_GET['id']))->find();
        $colums = M('mall_colums')->where("mall_id=%d",array($_GET['id']))->select();
        $this->assign("colums",$colums);
    	$this->assign("mall", $mall);
    	$this->display();
    }
    
    public function update_info(){
    	if( isset($_POST['mall']) ){
                
                $params = $_POST['mall'];
    		$params['detail'] = $_POST['mall_detail'];
    		$res = D('Mall')->update_info($params);
                $id=$_POST['mall']['id'];
                unset($_POST['mall']['id']);
    		if( $res['status'] ){
    			$this->set_notice(1, $notice);
    			$this->redirect("Mall/index");
    		}
    	}else{
    		$notice = "参数错误";
    	}
    	$this->set_notice(2, $notice);
    	$this->redirect('Mall/edit', array('id'=>$id));
    }
    
    public function del(){
    	$f = M('mall')->where("id=%d", array($_GET['id']))->setField(array('is_del'=>1));
    	if( $f!==false ){
    		$this->set_notice(1, "删除成功");
    	}else{
    		$this->set_notice(2, "删除出错，请重试");
    	}
    	$this->redirect("Mall/index");
    }
    
    public function upload_file(){
    	include_once SITE_PATH.'/Home/Model/FileUpload.class.php';
    	$FileUpload = new \FileUpload();
    	$path = $FileUpload->save_file($_POST['pname'], "/uploadfiles/products/".date('Y-m-d')."/");
    	if( $id>0 ){
    		echo "yes";
    	}else{
    		echo "no";
    	}
    	exit;
    }
    
    public function valid($options=array()){
		if( empty($options['name']) ){
			return array('status'=>false, 'msg'=>'商城名称');
		}
		return array('status'=>true, 'msg'=>'ok');
	}
        
        public function create_info_1( $options=array() ){
            
                $res = $this->valid($options);
		if(!$res['id']){ return $res; }
		$arr_status = $options['mall_detail'];
		unset($options['mall_detail']);
		M()->startTrans();
		$options['create_time'] = time();
//		$id = $this->add($options);
                $id = M('mall')->add($options);
		if( $id>0 ){
			foreach($arr_status as $value){
				$p_id = M('mall_colums')->add(array('mall_id'=>$id, 'name'=>$value['name'],'ptype_status_id'=>$value['or']));	
				if( $p_id<=0 ){
					M()->rollback();
                                        echo "aaa";
                                        eixt;
					return array('status'=>false, "msg"=>"添加失败");
				}
			}
			M()->commit();
                        echo "bbb";
                        exit;
			return array('status'=>true, 'msg'=>'添加成功');
		}else{
			M()->rollback();
                        echo "ccc";
                        exit;
			return array('status'=>false, "msg"=>"添加失败");
		}
        }
    
}