<?php
namespace Home\Controller;
use Common\Common\Controller\AdminBaseController;
class ItemsController extends AdminBaseController {
    
	public $locations = array();
	public $ptype_id;
	
	
	function __construct(){
		parent::__construct();
		$this->locations = array(
				array('is_checked'=>false, 'name'=>'项目管理', 'url'=>U('Home/AdminUser/index'))
		);
		
		$this->ptype_id = isset($_POST['ptype_id'])?intval($_POST['ptype_id']):isset($_GET['ptype_id'])?intval($_GET['ptype_id']):2;
		if( !empty($this->ptype_id) ){
			$_SESSION['ptype_id'] = $this->ptype_id; 
		}else{
			$this->ptype_id = $_SESSION['ptype_id'];
		}
		$ptype = M('ptypes')->where("id=%d", array($this->ptype_id))->find();
		$this->assign('loc_name_1', $ptype['name']);
		$this->assign('locations', $this->locations);
	}
	
	public function history(){
		$this->assign("loc_name_2", "历史删除项目");
		$search_info['ptype_id'] = $this->ptype_id;
		$search_info['is_del'] = 1;
		$search_info['num'] = isset($_POST['num'])?intval($_POST['num']):isset($_GET['num'])?intval($_GET['num']):10;
		$Items = D('Items');
		$res = $Items->search_info($search_info);
		$this->assign('Items', $Items);
		$this->assign('r_items', $res['items']);
		$this->assign('show_page', $res['show_page']);
		$this->display("Items/index");
	}
	
	public function list_items(){
		$this->assign("loc_name_2", "全部项目");
		$search_info['ptype_id'] = $this->ptype_id;
		$search_info['status'] = isset($_POST['status'])?intval($_POST['status']):isset($_GET['status'])?intval($_GET['status']):0;
		$search_info['num'] = isset($_POST['num'])?intval($_POST['num']):isset($_GET['num'])?intval($_GET['num']):10;
		$Items = D('Items');
		$res = $Items->search_info($search_info);
		$this->assign('Items', $Items);
		$this->assign('r_items', $res['items']);
		$this->assign('show_page', $res['show_page']);
		$col_status = M('ptype_status')->where("ptype_id=%d",array($search_info['ptype_id']))->field("id as val,name")->select();
		$this->assign('s_status', $col_status);
		$this->display("Items/index");
	}
	
	public function index(){
		$this->assign("loc_name_2", "未完成列表");
		$search_info['ptype_id'] = $this->ptype_id;
		$search_info['status'] = isset($_POST['status'])?intval($_POST['status']):isset($_GET['status'])?intval($_GET['status']):0;
		$search_info['num'] = isset($_POST['num'])?intval($_POST['num']):isset($_GET['num'])?intval($_GET['num']):10;
		if( empty($search_info['status']) ){
			$search_info['is_over'] = 0;
		}
		$Items = D('Items');
		$res = $Items->search_info($search_info);
		$this->assign('Items', $Items);
		$this->assign('r_items', $res['items']);
		$this->assign('show_page', $res['show_page']);
		$col_status = M('ptype_status')->where("ptype_id=%d",array($search_info['ptype_id']))->field("id as val,name")->select();
		$this->assign('s_status', $col_status);
    	$this->display();
    }
    
    public function add_info(){
    	$this->assign("loc_name_2", "添加");
    	$ptypes = M('ptypes')->where("is_del=0")->select();
    	$this->assign('ptypes', $ptypes);
    	$this->assign('item', array('ptype_id'=>$this->ptype_id));
    	$this->display();
    }
    
    public function create_info(){
    	if( isset($_POST['item']) ){
    		$_POST['item']['admin_user_id'] = $this->admin_user_id;
    		$res = D('Items')->create_info($_POST['item']);
    		$notice = $res['notice'];
    		if( $res['status'] ){
    			$this->set_notice(1, $notice);
    			$this->redirect("Home/Items/index");
    		}
    	}else{
    		$notice = "参数错误";
    	}
    	$this->set_notice(2, $notice);
    	$this->redirect('Home/Items/add_info');
    }
    
    public function edit(){
    	$this->assign("loc_name_2", "修改");
    	$item = M('items')->where("id=%d", array($_GET['id']))->find();
    	$this->assign('item', $item);
    	$this->display();
    }
    
    public function update_info(){
    	if( isset($_POST['item']) ){
    		$_POST['item']['admin_user_id'] = $this->admin_user_id;
    		$res = D('Items')->update_info($_POST['item']);
    		$notice = $res['notice'];
    		if( $res['status'] ){
    			$this->set_notice(1, $notice);
    			$this->redirect("Home/Items/index");
    		}
    	}else{
    		$notice = "参数错误";
    	}
    	$this->set_notice(2, $notice);
    	$this->redirect('Home/Items/edit', array('id'=>$_POST['item']['id']));
    }
    
    public function delete_item(){
    	$f = M('items')->where("id=%d", array($_GET['id']))->setField(array('is_del'=>1));
    	if( $f!==false ){
    		$this->set_notice(1, "删除成功");
    	}else{
    		$this->set_notice(2, "删除出错，请重试");
    	}
    	$this->redirect("Home/Items/index");
    }
    
    public function upload_file(){
    	include_once SITE_PATH.'/Home/Model/FileUpload.class.php';
    	$FileUpload = new \FileUpload();
    	$path = $FileUpload->save_file($_POST['pname'], "/uploadfiles/items/".date('Y-m-d')."/");
    	$item = M('items')->where("id=%d", array($_POST['id']))->find();
    	$id = M('items_attach')->add(array('item_id'=>$item['id'], 'name'=>$_POST['name'],
    								'create_time'=>time(), 'item_status_id'=>$item['item_status_id']));
    	if( $id>0 ){
    		echo "yes";
    	}else{
    		echo "no";
    	}
    	exit;
    }
    
    public function update_status(){
    	if( $_POST['t']=='over' ){
    		$item_status = M('item_status')->where("item_id=%d and ptype_status_id=%d", array($_POST['id'], $_POST['pid']))->setField(array('is_over'=>2));
    	}else if($_POST['t']=='agree'){
    		$item_status = M('item_status')->where("item_id=%d and ptype_status_id=%d", array($_POST['id'], $_POST['pid']))->setField(array('is_over'=>1));
    	}else if($_POST['t']=='unagree'){
    		$item_status = M('item_status')->where("item_id=%d and ptype_status_id=%d", array($_POST['id'], $_POST['pid']))->setField(array('is_over'=>-1));
    	}
    	$this->redirect("Items/index");
    }
    
}