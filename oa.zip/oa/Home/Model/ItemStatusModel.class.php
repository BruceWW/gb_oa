<?php
namespace Home\Model;
use Home\Model\BaseModel;
class ItemStatusModel extends BaseModel{
	
	protected $tableName = 'item_status';
	
	public function search(){
		
	}
	
	public function create_info(){
		
	}
	
	public function update_info(){
		
	}
	
}