function is_empty(str){
    return typeof(str)=='undefined' || str==null || str=='' || str.length==0 || str==0;
}

function is_not_number(str){  
    var reg = new RegExp("^[0-9]*$");   
    if( reg.test(str) ){  
        return false;
    }else{
        return true;
    }
}

function is_not_email(str){
    var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    if( reg.test(str) ){
       return false;
    }else{
       return true;
    }
}

function isPriceNumber(_keyword){  
    if(_keyword == "0" || _keyword == "0." || _keyword == "0.0" || _keyword == "0.00"){  
        _keyword = "0"; return true;  
    }else{  
        var index = _keyword.indexOf("0");  
        var length = _keyword.length;  
        if(index == 0 && length>1){/*0开头的数字串*/  
            var reg = /^[0]{1}[.]{1}[0-9]{1,2}$/;  
            if(!reg.test(_keyword)){  
                return false;  
            }else{  
                return true;  
            }  
        }else{/*非0开头的数字*/  
            var reg = /^[1-9]{1}[0-9]{0,10}[.]{0,1}[0-9]{0,2}$/;  
            if(!reg.test(_keyword)){  
                return false;  
            }else{  
                return true;  
            }  
        }             
        return false;  
    }  
}  

//
function is_not_date(str){
    return true;
}

function judge(obj, type){
    var f = true;
    switch(type){
        case "email":
            f = is_not_email(obj.val());
            break;
        case "date":
            f = is_not_date(obj.val());
            break;
        case "number":
            f = is_not_number(obj.val());
            break;
        case "price":
            f = !isPriceNumber(obj.val());
            break;
        default :
             f = is_empty(obj.val());
    }
    if( !f ){
        obj.parent().find("span.lbl").hide().removeClass("err");
        return true;
    }else{
        obj.parent().find("span.lbl").show().addClass("err");
        return false;
    }
}