$(document).ready(function(){
	
	$('#num').change(function(){
		$("#search_info").submit();
	});
 });