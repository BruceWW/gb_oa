$(document).ready(function(){
	
	$('#num').change(function(){
		$('#search_info').submit();
	});
	
	$('#admin_user_deport_id').change(function(){
		 $.get($(this).attr('vel'), {id:$(this).val()}, function(data){
			 $('#admin_user_role_id').html(data);
		 });
	});
	
         $("#btn").click(function(){
            if( valid() ){
                return true;
            }else{
                return false;
            }
        });
        
        $("#admin_user_deport_id,#admin_user_role_id, #admin_user_username,"+
          "#admin_user_password,#admin_user_confirm_password,#admin_user_mobile,#admin_user_address,").focus(function(){
            $(this).parent().find("span.lbl").hide().removeClass("err");
        });
        
});

function valid(){
    var f1 = judge($("#admin_user_deport_id"), "empty");
    var f2 = judge($("#admin_user_role_id"), "empty");
    var f3 = judge($("#admin_user_username"), "empty");
    var f4 = judge($("#admin_user_password"), "empty");
    var f5 = judge($("#admin_user_confirm_password"), "empty");
    var f6 = judge($("#admin_user_mobile"), "empty");
    var f7 = judge($("#admin_user_address"), "empty");

    return (f1&&f2&&f3&&f4&&f5&&f6&&f7);
}