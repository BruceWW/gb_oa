$(document).ready(function(){
	$('#num').change(function(){
		$('#search_info').submit();
	});
        
	$("#product_category_id").change(function(){
		$.post($(this).attr("vel"), {category_id:$(this).val()}, function(data){
			$("#product_sub_category_id").html(data);
		});
	});
	
});