$(document).ready(function(){
	
	$('#num').change(function(){
		$("#search_info").submit();
	});
	
	$("tr[name='item'] td[name='td-item']").click(function(){
		var i = $(this).parent().attr("vel");
		if( $("#item_"+i).attr("data-s")=='1' ){
			$("#item_"+i).attr("data-s", '0');
			$("#item_"+i).hide();
		}else{
			$("#item_"+i).attr("data-s", '1');
			$("#item_"+i).show();
		}
	});
	
});