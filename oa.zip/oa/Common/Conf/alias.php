<?php 

return array(
	'SimpleHtmlDom' => SPAPP_PATH.'/simple_html_dom/SimpleHtmlDom.class.php',
	'Curl' => SPAPP_PATH.'/Util/Curl.class.php',
	"ExcelToArrary"=>SPAPP_PATH.'/Util/ExcelToArrary.class.php',
		
	//验证码
	'Image' => SPAPP_PATH.'/Util/Image.class.php',
	'String' => SPAPP_PATH.'/Util/String.class.php',
	'Page' => SPAPP_PATH.'/Util/Page.class.php',
	'PHPMailer' => SPAPP_PATH."/phpmailer/class.phpmailer.php",
	'PHPSmtp' => SPAPP_PATH."/phpmailer/class.smtp.php",
);

